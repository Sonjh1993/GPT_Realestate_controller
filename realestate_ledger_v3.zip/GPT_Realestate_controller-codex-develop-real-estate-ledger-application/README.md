# GPT_Realestate_controller
엄마 부동산 장부용 프로그램 (데스크탑 / 오프라인 우선)

## 핵심 방향
- **Google API 키가 없어도 100% 운영 가능**
  - 로컬 SQLite에 저장
  - Drive 동기화 폴더에 CSV/JSON/ICS/사진을 내보내기(export) → 어디서나 열람
- (선택) Apps Script Webhook(URL)만 있으면 즉시 Google Sheets에도 업로드
- 모든 기능은 **UI 버튼/화면에서 수행** (엑셀 직접 편집 불필요)

---

## 1) 아키텍처
- UI: Python `tkinter` 데스크탑 앱
- DB: SQLite (`app/ledger.db`)
- 파일 내보내기(기본): `동기화폴더/exports/`에 생성
  - `visible_properties.csv`
  - `visible_customers.csv`
  - `open_tasks.csv` (오늘 할 일/업무 큐)
  - `snapshot.json` (Gemini/검색/요약용)
  - `viewings.ics` (Google Calendar 가져오기용)
  - `proposals/` (고객 제안서 PDF/TXT)
- (선택) Webhook 업로드: `GOOGLE_SHEETS_WEBHOOK_URL`로 JSON POST

---

## 2) 제공 기능
- **오늘(대시보드)**: 전체/숨김 건수 + 7일 일정 + 할 일(Next Action)
- **물건**: 등록/수정/상세(팝업)/숨김·보임/삭제(소프트 삭제)
- **사진**: 물건별 사진 업로드(동기화 폴더로 자동 복사) + 목록 관리
- **일정**: 물건별 일정 등록(로컬 저장) + 내보내기 시 ICS 생성
- **고객**: 요구사항 등록/수정/숨김·보임/삭제(소프트 삭제)
- **매칭**: 고객 선택 → 조건 기반 후보 물건 추천(규칙 기반)
- **설정 UI**: 동기화 폴더/웹훅 URL을 앱에서 설정

---

## 3) 실행 방법
```bash
# (권장) 제안서 PDF 기능까지 쓰려면
pip install -r requirements.txt

python run.py
```

---

## 4) API 없이 운영(권장 초기 운영)
1. 앱의 **[설정]** 탭에서 `Drive 동기화 폴더`를 지정
   - 예: `~/Google Drive/부동산장부` (Drive Desktop이 동기화하는 경로)
2. **[오늘]** 또는 상단 버튼의 `내보내기/동기화` 클릭
3. Drive에서 `exports/`의 CSV/JSON/ICS 파일을 어디서나 열람

---

## 5) (선택) Google Sheets 즉시 반영(Webhook)
1. Google Apps Script 웹앱을 배포해 POST JSON을 받아 시트에 기록하도록 구성
2. 앱의 **[설정]** 탭에서 `Sheets 웹훅 URL` 저장
3. `내보내기/동기화` 실행 시
   - 파일 내보내기 + 웹훅 업로드를 같이 수행

---

## 6) 왜 "서버"가 없어도 되나?
- 입력/조회/숨김관리 = 로컬 앱(UI)
- 공유/열람 = Drive 동기화(파일 기반)
- 캘린더 = ICS 내보내기(import)로 시작 → 나중에 Google Calendar API로 고도화
