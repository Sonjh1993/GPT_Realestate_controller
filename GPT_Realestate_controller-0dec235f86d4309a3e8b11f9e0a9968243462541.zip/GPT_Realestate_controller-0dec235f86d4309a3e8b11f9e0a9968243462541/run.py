from app.desktop_app import run_desktop_app


if __name__ == "__main__":
    run_desktop_app()
