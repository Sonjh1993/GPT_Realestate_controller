from app.api_service import run_api_server

if __name__ == "__main__":
    run_api_server(host="0.0.0.0", port=8000)
